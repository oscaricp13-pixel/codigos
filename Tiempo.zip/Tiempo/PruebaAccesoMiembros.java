public class PruebaAccesoMiembros{
//crea una clase de tipo controlador//
    public static void main (String [] args){
//crea un objeto llamdo tiempo de la clase Tiempo1//
Tiempo1 tiempo = new Tiempo1();

//asigna valores a los atributos sin usar setter//
tiempo.hora = 7;
tiempo.minuto = 15;
tiempo.segundo = 30;
    }
}