public class CuadradoTest{

    public static void main(String[] args) {
        
Cuadrado cuadrado = new Cuadrado(7.0);

System.out.println("area del cuadrado: " + cuadrado.CalcularArea());
System.err.println("perimetro del cuadrado: " + cuadrado.CalcularPerimetro());

    }
}