// PorPagar.java
public interface PorPagar {
    double obtenerMontoPago(); // calcula el pago, no hay implementación
}